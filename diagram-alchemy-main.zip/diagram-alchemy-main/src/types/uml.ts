export type DiagramType = "sequence" | "class" | "usecase" | "activity" | "state";

export interface DiagramTypeDetection {
  type: DiagramType;
  confidence: number;
  reasoning: string;
}

export interface ModelOption {
  id: string;
  label: string;
  provider: string;
  speed: string;
  backendModel: string;
}

export const MODEL_OPTIONS: ModelOption[] = [
  { id: "gpt4o", label: "GPT-4o", provider: "OpenAI", speed: "Most Accurate", backendModel: "openai/gpt-5" },
  { id: "gpt4o-mini", label: "GPT-4o-mini", provider: "OpenAI", speed: "Fast", backendModel: "openai/gpt-5-mini" },
  { id: "claude-sonnet", label: "Claude 3.5 Sonnet", provider: "Anthropic", speed: "Balanced", backendModel: "google/gemini-2.5-pro" },
  { id: "claude-haiku", label: "Claude 3 Haiku", provider: "Anthropic", speed: "Fast", backendModel: "google/gemini-2.5-flash" },
  { id: "gemini-pro", label: "Gemini Pro", provider: "Google", speed: "Accurate", backendModel: "google/gemini-3-pro-preview" },
  { id: "gemini-flash", label: "Gemini Flash", provider: "Google", speed: "Fast", backendModel: "google/gemini-3-flash-preview" },
];

// Sequence diagram types
export interface SequenceParticipant {
  name: string;
  alias?: string;
  kind: "actor" | "participant" | "boundary" | "control" | "entity" | "database";
}

export interface SequenceMessage {
  order: number;
  from: string;
  to: string;
  label: string;
  type: "sync" | "async" | "return" | "create" | "destroy";
  uncertain?: boolean;
  auto_fixed?: boolean;
}

export interface SequenceDiagram {
  participants: SequenceParticipant[];
  messages: SequenceMessage[];
}

// Class diagram types
export interface ClassAttribute {
  name: string;
  type?: string;
  visibility?: "+" | "-" | "#" | "~";
  uncertain?: boolean;
}

export interface ClassMethod {
  name: string;
  returnType?: string;
  params?: string;
  visibility?: "+" | "-" | "#" | "~";
  uncertain?: boolean;
}

export interface ClassEntity {
  name: string;
  attributes: ClassAttribute[];
  methods: ClassMethod[];
  uncertain?: boolean;
}

export interface ClassRelationship {
  from: string;
  to: string;
  type: "inheritance" | "implementation" | "association" | "aggregation" | "composition" | "dependency";
  cardinality?: string;
  label?: string;
  uncertain?: boolean;
  auto_fixed?: boolean;
}

export interface ClassDiagram {
  classes: ClassEntity[];
  relationships: ClassRelationship[];
}

// Use case diagram types
export interface UseCaseActor {
  name: string;
  uncertain?: boolean;
}

export interface UseCase {
  id: string;
  name: string;
  uncertain?: boolean;
}

export interface UseCaseLink {
  from: string;
  to: string;
  type: "association" | "include" | "extend" | "generalization";
  uncertain?: boolean;
  auto_fixed?: boolean;
}

export interface UseCaseDiagram {
  actors: UseCaseActor[];
  usecases: UseCase[];
  links: UseCaseLink[];
}

// Activity diagram types
export interface ActivityNode {
  id: string;
  name: string;
  type: "action" | "decision" | "fork" | "join" | "start" | "end";
  uncertain?: boolean;
}

export interface ActivityEdge {
  from: string;
  to: string;
  label?: string;
  uncertain?: boolean;
  auto_fixed?: boolean;
}

export interface ActivityDiagram {
  nodes: ActivityNode[];
  edges: ActivityEdge[];
}

// State diagram types
export interface StateNode {
  id: string;
  name: string;
  type: "state" | "start" | "end" | "composite";
  uncertain?: boolean;
}

export interface StateTransition {
  from: string;
  to: string;
  trigger?: string;
  guard?: string;
  uncertain?: boolean;
  auto_fixed?: boolean;
}

export interface StateDiagram {
  states: StateNode[];
  transitions: StateTransition[];
}

export type ExtractedData = SequenceDiagram | ClassDiagram | UseCaseDiagram | ActivityDiagram | StateDiagram;

export interface ValidationError {
  type: "referential" | "syntax" | "semantic";
  message: string;
  severity: "error" | "warning";
}

export interface AutoFix {
  description: string;
  field: string;
  oldValue: string;
  newValue: string;
}

export interface ExtractionResult {
  diagramType: DiagramType;
  data: ExtractedData;
  validationErrors: ValidationError[];
  autoFixes: AutoFix[];
  rawResponse?: string;
  model: string;
  confidence: number;
}

export interface DebugInfo {
  model: string;
  imageSize: number;
  detectedType: DiagramType;
  confidence: number;
  elementCount: number;
  validationErrors: number;
  autoFixes: number;
  rawResponse: string;
}

export type AppStep = "upload" | "detect" | "extract" | "review" | "generate";
