import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { validateExtraction, countElements } from "@/lib/validation";
import { generatePlantUML } from "@/lib/plantuml-generator";
import { MODEL_OPTIONS } from "@/types/uml";
import type {
  DiagramType, DiagramTypeDetection, ExtractionResult, DebugInfo, AppStep, ExtractedData,
} from "@/types/uml";
import { toast } from "sonner";

async function getFunctionErrorMessage(error: any): Promise<string> {
  if (error?.context && typeof error.context.json === "function") {
    try {
      const payload = await error.context.json();
      if (payload?.error) return payload.error;
    } catch {
      // Ignore body parse errors and fall back to generic error message.
    }
  }
  return error?.message || "Unknown error";
}

export function useUmlExtraction() {
  const [step, setStep] = useState<AppStep>("upload");
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSize, setFileSize] = useState<number | null>(null);
  const [detection, setDetection] = useState<DiagramTypeDetection | null>(null);
  const [selectedType, setSelectedType] = useState<DiagramType | null>(null);
  const [selectedModel, setSelectedModel] = useState("gemini-flash");
  const [extractionResult, setExtractionResult] = useState<ExtractionResult | null>(null);
  const [plantUML, setPlantUML] = useState("");
  const [debugInfo, setDebugInfo] = useState<DebugInfo | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const getBackendModel = useCallback(() => {
    return MODEL_OPTIONS.find(m => m.id === selectedModel)?.backendModel || "google/gemini-3-flash-preview";
  }, [selectedModel]);

  const handleImageSelect = useCallback(async (file: File, base64: string) => {
    setImageBase64(base64);
    setImageMimeType(file.type || "image/png");
    setFileName(file.name);
    setFileSize(file.size);
    setStep("detect");
    setDetection(null);
    setSelectedType(null);
    setExtractionResult(null);
    setPlantUML("");
    setDebugInfo(null);

    // Auto-detect type
    setIsDetecting(true);
    try {
      const { data, error } = await supabase.functions.invoke("extract-uml", {
        body: {
          action: "detect",
          imageBase64: base64,
          imageMimeType: file.type || "image/png",
          model: getBackendModel(),
        },
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);

      const det = data.result as DiagramTypeDetection;
      setDetection(det);
      if (det.confidence >= 0.7) {
        setSelectedType(det.type);
      }
    } catch (e: any) {
      toast.error("Detection failed: " + (await getFunctionErrorMessage(e)));
    } finally {
      setIsDetecting(false);
    }
  }, [getBackendModel]);

  const handleClear = useCallback(() => {
    setImageBase64(null);
    setImageMimeType(null);
    setFileName(null);
    setFileSize(null);
    setDetection(null);
    setSelectedType(null);
    setExtractionResult(null);
    setPlantUML("");
    setDebugInfo(null);
    setStep("upload");
  }, []);

  const handleExtract = useCallback(async () => {
    if (!imageBase64 || !selectedType) return;

    setIsExtracting(true);
    setStep("extract");
    try {
      const model = getBackendModel();
      const { data, error } = await supabase.functions.invoke("extract-uml", {
        body: { action: "extract", imageBase64, imageMimeType, diagramType: selectedType, model },
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);

      const extractedData = data.result as ExtractedData;
      const { errors, fixes } = validateExtraction(selectedType, extractedData);

      const result: ExtractionResult = {
        diagramType: selectedType,
        data: extractedData,
        validationErrors: errors,
        autoFixes: fixes,
        rawResponse: data.raw,
        model,
        confidence: detection?.confidence || 0,
      };

      setExtractionResult(result);
      setDebugInfo({
        model,
        imageSize: fileSize || 0,
        detectedType: selectedType,
        confidence: detection?.confidence || 0,
        elementCount: countElements(selectedType, extractedData),
        validationErrors: errors.length,
        autoFixes: fixes.length,
        rawResponse: data.raw || "",
      });
      setStep("review");
    } catch (e: any) {
      toast.error("Extraction failed: " + (await getFunctionErrorMessage(e)));
      setStep("detect");
    } finally {
      setIsExtracting(false);
    }
  }, [imageBase64, imageMimeType, selectedType, getBackendModel, detection, fileSize]);

  const handleConfirmAndGenerate = useCallback((_excludedIndices: Set<string>) => {
    if (!extractionResult) return;
    setIsGenerating(true);
    try {
      const uml = generatePlantUML(extractionResult.diagramType, extractionResult.data);
      if (!uml || uml.trim() === "@startuml\n@enduml") {
        toast.error("Generated PlantUML is empty. Check extracted data.");
        return;
      }
      setPlantUML(uml);
      setStep("generate");
    } catch (e: any) {
      toast.error("Generation failed: " + (e.message || "Unknown error"));
    } finally {
      setIsGenerating(false);
    }
  }, [extractionResult]);

  return {
    step, imageBase64, imageMimeType, fileName, fileSize,
    detection, selectedType, setSelectedType,
    selectedModel, setSelectedModel,
    extractionResult, plantUML, debugInfo,
    isDetecting, isExtracting, isGenerating,
    handleImageSelect, handleClear, handleExtract, handleConfirmAndGenerate,
  };
}
