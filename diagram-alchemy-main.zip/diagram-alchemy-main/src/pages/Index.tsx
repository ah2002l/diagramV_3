import { Button } from "@/components/ui/button";
import { ImageUpload } from "@/components/uml/ImageUpload";
import { ModelSelector } from "@/components/uml/ModelSelector";
import { DiagramTypeSelector } from "@/components/uml/DiagramTypeSelector";
import { ExtractionReview } from "@/components/uml/ExtractionReview";
import { PlantUMLPreview } from "@/components/uml/PlantUMLPreview";
import { DebugPanel } from "@/components/uml/DebugPanel";
import { useUmlExtraction } from "@/hooks/useUmlExtraction";
import { Beaker, Play, Loader2, RotateCcw } from "lucide-react";

const Index = () => {
  const {
    step, imageBase64, imageMimeType, fileName, fileSize,
    detection, selectedType, setSelectedType,
    selectedModel, setSelectedModel,
    extractionResult, plantUML, debugInfo,
    isDetecting, isExtracting, isGenerating,
    handleImageSelect, handleClear, handleExtract, handleConfirmAndGenerate,
  } = useUmlExtraction();

  const canExtract = selectedType && imageBase64 && !isExtracting && !isDetecting;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="shrink-0 border-b border-border bg-card/50 px-6 py-3">
        <div className="flex items-center gap-3">
          <Beaker className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-bold tracking-tight">
            <span className="text-gradient">UML Extraction Lab</span>
          </h1>
          <span className="text-xs text-muted-foreground font-mono ml-auto hidden sm:block">
            {step === "upload" && "① Upload"}
            {step === "detect" && "② Detect & Configure"}
            {step === "extract" && "③ Extracting..."}
            {step === "review" && "④ Review"}
            {step === "generate" && "⑤ Output"}
          </span>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* LEFT PANEL */}
        <div className="w-full lg:w-[420px] shrink-0 border-r border-border overflow-y-auto p-5 space-y-5">
          {/* Image Upload */}
          <ImageUpload
            onImageSelect={handleImageSelect}
            onClear={handleClear}
            imagePreview={imageBase64}
            imageMimeType={imageMimeType}
            fileName={fileName}
            fileSize={fileSize}
          />

          {/* Model Selector */}
          {imageBase64 && (
            <ModelSelector
              value={selectedModel}
              onChange={setSelectedModel}
              disabled={isExtracting}
            />
          )}

          {/* Diagram Type */}
          {imageBase64 && (
            <DiagramTypeSelector
              detection={detection}
              selectedType={selectedType}
              onTypeChange={setSelectedType}
              isDetecting={isDetecting}
            />
          )}

          {/* Extract Button */}
          {imageBase64 && selectedType && step !== "review" && step !== "generate" && (
            <Button
              onClick={handleExtract}
              disabled={!canExtract}
              className="w-full"
              size="lg"
            >
              {isExtracting ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Extracting...</>
              ) : (
                <><Play className="h-4 w-4 mr-2" />Extract Elements</>
              )}
            </Button>
          )}

          {/* Re-extract button */}
          {(step === "review" || step === "generate") && (
            <Button variant="secondary" onClick={handleExtract} disabled={isExtracting} className="w-full">
              <RotateCcw className="h-4 w-4 mr-2" />
              Re-extract with {selectedModel}
            </Button>
          )}

          {/* Review */}
          {extractionResult && step === "review" && (
            <ExtractionReview
              result={extractionResult}
              onConfirm={handleConfirmAndGenerate}
              isLoading={isGenerating}
            />
          )}

          {/* Debug Panel */}
          <DebugPanel info={debugInfo} />
        </div>

        {/* RIGHT PANEL */}
        <div className="flex-1 overflow-hidden bg-muted/10">
          <PlantUMLPreview plantUML={plantUML} diagramType={selectedType || "sequence"} />
        </div>
      </div>
    </div>
  );
};

export default Index;
