import type {
  DiagramType, ExtractedData, ValidationError, AutoFix,
  SequenceDiagram, ClassDiagram, UseCaseDiagram, ActivityDiagram, StateDiagram,
} from "@/types/uml";

function validateSequence(data: SequenceDiagram): { errors: ValidationError[]; fixes: AutoFix[] } {
  const errors: ValidationError[] = [];
  const fixes: AutoFix[] = [];
  const names = new Set(data.participants.map(p => p.name));

  for (let i = 0; i < data.messages.length; i++) {
    const m = data.messages[i];
    if (!names.has(m.from)) {
      errors.push({ type: "referential", message: `Message ${i}: sender "${m.from}" not in participants`, severity: "error" });
    }
    if (!names.has(m.to)) {
      errors.push({ type: "referential", message: `Message ${i}: receiver "${m.to}" not in participants`, severity: "error" });
    }
    if (m.from === m.to && m.type !== "sync") {
      fixes.push({ description: "Self-call type normalized", field: `messages[${i}].type`, oldValue: m.type, newValue: "sync" });
      m.type = "sync";
      m.auto_fixed = true;
    }
  }

  // Fix ordering
  const sorted = [...data.messages].sort((a, b) => a.order - b.order);
  for (let i = 0; i < sorted.length; i++) {
    if (sorted[i].order !== i + 1) {
      fixes.push({ description: "Message order renumbered", field: `messages[${i}].order`, oldValue: String(sorted[i].order), newValue: String(i + 1) });
      sorted[i].order = i + 1;
      sorted[i].auto_fixed = true;
    }
  }
  data.messages = sorted;

  return { errors, fixes };
}

function validateClass(data: ClassDiagram): { errors: ValidationError[]; fixes: AutoFix[] } {
  const errors: ValidationError[] = [];
  const fixes: AutoFix[] = [];
  const classNames = new Set(data.classes.map(c => c.name));

  for (const r of data.relationships) {
    if (!classNames.has(r.from)) {
      errors.push({ type: "referential", message: `Relationship: source "${r.from}" not found`, severity: "error" });
    }
    if (!classNames.has(r.to)) {
      errors.push({ type: "referential", message: `Relationship: target "${r.to}" not found`, severity: "error" });
    }
  }

  return { errors, fixes };
}

function validateUseCase(data: UseCaseDiagram): { errors: ValidationError[]; fixes: AutoFix[] } {
  const errors: ValidationError[] = [];
  const fixes: AutoFix[] = [];
  const actorNames = new Set(data.actors.map(a => a.name));
  const ucIds = new Set(data.usecases.map(uc => uc.id));

  for (const l of data.links) {
    const fromValid = actorNames.has(l.from) || ucIds.has(l.from);
    const toValid = actorNames.has(l.to) || ucIds.has(l.to);
    if (!fromValid) errors.push({ type: "referential", message: `Link: source "${l.from}" not found`, severity: "error" });
    if (!toValid) errors.push({ type: "referential", message: `Link: target "${l.to}" not found`, severity: "error" });
  }

  return { errors, fixes };
}

function validateActivity(data: ActivityDiagram): { errors: ValidationError[]; fixes: AutoFix[] } {
  const errors: ValidationError[] = [];
  const fixes: AutoFix[] = [];
  const nodeIds = new Set(data.nodes.map(n => n.id));

  for (const e of data.edges) {
    if (!nodeIds.has(e.from)) errors.push({ type: "referential", message: `Edge: source "${e.from}" not found`, severity: "error" });
    if (!nodeIds.has(e.to)) errors.push({ type: "referential", message: `Edge: target "${e.to}" not found`, severity: "error" });
  }

  return { errors, fixes };
}

function validateState(data: StateDiagram): { errors: ValidationError[]; fixes: AutoFix[] } {
  const errors: ValidationError[] = [];
  const fixes: AutoFix[] = [];
  const stateIds = new Set(data.states.map(s => s.id));

  for (const t of data.transitions) {
    if (!stateIds.has(t.from)) errors.push({ type: "referential", message: `Transition: source "${t.from}" not found`, severity: "error" });
    if (!stateIds.has(t.to)) errors.push({ type: "referential", message: `Transition: target "${t.to}" not found`, severity: "error" });
  }

  return { errors, fixes };
}

export function validateExtraction(type: DiagramType, data: ExtractedData): { errors: ValidationError[]; fixes: AutoFix[] } {
  switch (type) {
    case "sequence": return validateSequence(data as SequenceDiagram);
    case "class": return validateClass(data as ClassDiagram);
    case "usecase": return validateUseCase(data as UseCaseDiagram);
    case "activity": return validateActivity(data as ActivityDiagram);
    case "state": return validateState(data as StateDiagram);
    default: return { errors: [], fixes: [] };
  }
}

export function countElements(type: DiagramType, data: ExtractedData): number {
  switch (type) {
    case "sequence": {
      const d = data as SequenceDiagram;
      return d.participants.length + d.messages.length;
    }
    case "class": {
      const d = data as ClassDiagram;
      return d.classes.length + d.relationships.length;
    }
    case "usecase": {
      const d = data as UseCaseDiagram;
      return d.actors.length + d.usecases.length + d.links.length;
    }
    case "activity": {
      const d = data as ActivityDiagram;
      return d.nodes.length + d.edges.length;
    }
    case "state": {
      const d = data as StateDiagram;
      return d.states.length + d.transitions.length;
    }
    default: return 0;
  }
}
