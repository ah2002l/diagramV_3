import type {
  DiagramType, ExtractedData, SequenceDiagram, ClassDiagram,
  UseCaseDiagram, ActivityDiagram, StateDiagram,
} from "@/types/uml";

function generateSequence(data: SequenceDiagram): string {
  const lines: string[] = ["@startuml"];
  for (const p of data.participants) {
    const kind = p.kind === "participant" ? "participant" : p.kind;
    const alias = p.alias ? ` as ${p.alias}` : "";
    lines.push(`${kind} "${p.name}"${alias}`);
  }
  lines.push("");
  const sorted = [...data.messages].sort((a, b) => a.order - b.order);
  for (const m of sorted) {
    const arrow = m.type === "async" ? "->>" : m.type === "return" ? "-->" : "->";
    lines.push(`"${m.from}" ${arrow} "${m.to}" : ${m.label}`);
  }
  lines.push("@enduml");
  return lines.join("\n");
}

function generateClass(data: ClassDiagram): string {
  const lines: string[] = ["@startuml"];
  for (const c of data.classes) {
    lines.push(`class ${c.name} {`);
    for (const a of c.attributes) {
      const vis = a.visibility || "+";
      lines.push(`  ${vis}${a.name}${a.type ? ` : ${a.type}` : ""}`);
    }
    for (const m of c.methods) {
      const vis = m.visibility || "+";
      lines.push(`  ${vis}${m.name}(${m.params || ""})${m.returnType ? ` : ${m.returnType}` : ""}`);
    }
    lines.push("}");
    lines.push("");
  }
  const relMap: Record<string, string> = {
    inheritance: "--|>",
    implementation: "..|>",
    association: "-->",
    aggregation: "o--",
    composition: "*--",
    dependency: "..>",
  };
  for (const r of data.relationships) {
    const arrow = relMap[r.type] || "-->";
    const label = r.label ? ` : ${r.label}` : "";
    const card = r.cardinality ? ` "${r.cardinality}"` : "";
    lines.push(`${r.from} ${arrow}${card} ${r.to}${label}`);
  }
  lines.push("@enduml");
  return lines.join("\n");
}

function generateUseCase(data: UseCaseDiagram): string {
  const lines: string[] = ["@startuml"];
  for (const a of data.actors) {
    lines.push(`actor "${a.name}"`);
  }
  lines.push("");
  lines.push("rectangle System {");
  for (const uc of data.usecases) {
    lines.push(`  usecase "${uc.name}" as ${uc.id}`);
  }
  lines.push("}");
  lines.push("");
  for (const l of data.links) {
    if (l.type === "include") {
      lines.push(`${l.from} ..> ${l.to} : <<include>>`);
    } else if (l.type === "extend") {
      lines.push(`${l.from} ..> ${l.to} : <<extend>>`);
    } else if (l.type === "generalization") {
      lines.push(`${l.from} --|> ${l.to}`);
    } else {
      lines.push(`"${l.from}" --> ${l.to}`);
    }
  }
  lines.push("@enduml");
  return lines.join("\n");
}

function generateActivity(data: ActivityDiagram): string {
  const lines: string[] = ["@startuml"];
  const nodeMap = new Map(data.nodes.map(n => [n.id, n]));
  const startNode = data.nodes.find(n => n.type === "start");
  if (startNode) lines.push("start");

  const visited = new Set<string>();
  const queue = startNode ? [startNode.id] : [];

  while (queue.length > 0) {
    const currentId = queue.shift()!;
    if (visited.has(currentId)) continue;
    visited.add(currentId);

    const node = nodeMap.get(currentId);
    if (!node) continue;

    if (node.type === "action") {
      lines.push(`:${node.name};`);
    } else if (node.type === "decision") {
      lines.push(`if (${node.name}) then (yes)`);
    } else if (node.type === "end") {
      lines.push("stop");
    }

    const outEdges = data.edges.filter(e => e.from === currentId);
    for (const edge of outEdges) {
      queue.push(edge.to);
    }
  }

  lines.push("@enduml");
  return lines.join("\n");
}

function generateState(data: StateDiagram): string {
  const lines: string[] = ["@startuml"];
  for (const s of data.states) {
    if (s.type === "start") continue;
    if (s.type === "end") continue;
    lines.push(`state "${s.name}" as ${s.id}`);
  }
  lines.push("");
  for (const t of data.transitions) {
    const fromState = data.states.find(s => s.id === t.from);
    const toState = data.states.find(s => s.id === t.to);
    const from = fromState?.type === "start" ? "[*]" : t.from;
    const to = toState?.type === "end" ? "[*]" : t.to;
    const label = t.trigger ? ` : ${t.trigger}${t.guard ? ` [${t.guard}]` : ""}` : "";
    lines.push(`${from} --> ${to}${label}`);
  }
  lines.push("@enduml");
  return lines.join("\n");
}

export function generatePlantUML(type: DiagramType, data: ExtractedData): string {
  switch (type) {
    case "sequence": return generateSequence(data as SequenceDiagram);
    case "class": return generateClass(data as ClassDiagram);
    case "usecase": return generateUseCase(data as UseCaseDiagram);
    case "activity": return generateActivity(data as ActivityDiagram);
    case "state": return generateState(data as StateDiagram);
    default: return "@startuml\n' Unsupported diagram type\n@enduml";
  }
}
