import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Copy, Check, FileCode, FileText } from "lucide-react";
import { sha256 } from "@/lib/sha256";

interface PlantUMLPreviewProps {
  plantUML: string;
  diagramType: string;
}

export function PlantUMLPreview({ plantUML, diagramType }: PlantUMLPreviewProps) {
  const [copied, setCopied] = useState<string | null>(null);
  const [hash, setHash] = useState("");
  const [groundTruth, setGroundTruth] = useState("");

  useEffect(() => {
    if (!plantUML) return;
    sha256(plantUML).then(h => {
      setHash(h);
      setGroundTruth(
`--- GROUND TRUTH START ---
Diagram Type: ${diagramType}
SHA256: ${h}
PlantUML:
${plantUML}
--- GROUND TRUTH END ---

Instructions for code generation:
1. Parse the PlantUML above
2. Generate equivalent code in the target language
3. Preserve all names, relationships, and structure exactly
4. Do not add elements not present in the diagram`
      );
    });
  }, [plantUML, diagramType]);

  const copyToClipboard = async (text: string, key: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  if (!plantUML) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
        <div className="text-center space-y-2">
          <FileCode className="h-12 w-12 mx-auto opacity-30" />
          <p>PlantUML will appear here after extraction</p>
        </div>
      </div>
    );
  }

  return (
    <Tabs defaultValue="plantuml" className="h-full flex flex-col animate-fade-in">
      <TabsList className="bg-muted border-b border-border rounded-none shrink-0">
        <TabsTrigger value="plantuml" className="gap-1.5 text-xs">
          <FileCode className="h-3.5 w-3.5" />
          PlantUML
        </TabsTrigger>
        <TabsTrigger value="prompt" className="gap-1.5 text-xs">
          <FileText className="h-3.5 w-3.5" />
          Ground Truth Prompt
        </TabsTrigger>
      </TabsList>

      <TabsContent value="plantuml" className="flex-1 mt-0 overflow-auto">
        <div className="relative">
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 h-7 text-xs z-10"
            onClick={() => copyToClipboard(plantUML, "plantuml")}
          >
            {copied === "plantuml" ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
          <pre className="p-4 font-mono text-xs leading-relaxed text-foreground overflow-auto">
            {plantUML}
          </pre>
        </div>
      </TabsContent>

      <TabsContent value="prompt" className="flex-1 mt-0 overflow-auto">
        <div className="relative">
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 h-7 text-xs z-10"
            onClick={() => copyToClipboard(groundTruth, "prompt")}
          >
            {copied === "prompt" ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
          <pre className="p-4 font-mono text-xs leading-relaxed text-foreground whitespace-pre-wrap overflow-auto">
            {groundTruth}
          </pre>
        </div>
        {hash && (
          <div className="px-4 pb-3 text-xs text-muted-foreground font-mono">
            SHA256: {hash}
          </div>
        )}
      </TabsContent>
    </Tabs>
  );
}
