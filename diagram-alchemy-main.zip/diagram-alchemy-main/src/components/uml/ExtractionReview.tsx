import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Checkbox } from "@/components/ui/checkbox";
import type { ExtractionResult, SequenceDiagram, ClassDiagram, UseCaseDiagram } from "@/types/uml";
import { ChevronDown, ChevronRight, Check, AlertTriangle, Wrench } from "lucide-react";

interface ExtractionReviewProps {
  result: ExtractionResult;
  onConfirm: (excludedIndices: Set<string>) => void;
  isLoading: boolean;
}

function ItemBadge({ uncertain, autoFixed }: { uncertain?: boolean; autoFixed?: boolean }) {
  if (autoFixed) return <Badge className="bg-info/20 text-info border-info/30 text-xs"><Wrench className="h-3 w-3 mr-1" />Auto-fixed</Badge>;
  if (uncertain) return <Badge className="bg-warning/20 text-warning border-warning/30 text-xs"><AlertTriangle className="h-3 w-3 mr-1" />Uncertain</Badge>;
  return null;
}

export function ExtractionReview({ result, onConfirm, isLoading }: ExtractionReviewProps) {
  const [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [openSections, setOpenSections] = useState<Set<string>>(new Set(["elements", "relationships"]));

  const toggle = (key: string) => {
    setExcluded(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const toggleSection = (section: string) => {
    setOpenSections(prev => {
      const next = new Set(prev);
      if (next.has(section)) next.delete(section); else next.add(section);
      return next;
    });
  };

  const renderSequence = (data: SequenceDiagram) => (
    <>
      <ReviewSection title="Participants" count={data.participants.length} open={openSections.has("elements")} onToggle={() => toggleSection("elements")}>
        {data.participants.map((p, i) => (
          <ReviewItem key={i} id={`p-${i}`} label={`${p.name} (${p.kind})`} excluded={excluded} onToggle={toggle} />
        ))}
      </ReviewSection>
      <ReviewSection title="Messages" count={data.messages.length} open={openSections.has("relationships")} onToggle={() => toggleSection("relationships")}>
        {data.messages.map((m, i) => (
          <ReviewItem key={i} id={`m-${i}`} label={`${m.order}. ${m.from} → ${m.to}: ${m.label}`} excluded={excluded} onToggle={toggle} uncertain={m.uncertain} autoFixed={m.auto_fixed} />
        ))}
      </ReviewSection>
    </>
  );

  const renderClass = (data: ClassDiagram) => (
    <>
      <ReviewSection title="Classes" count={data.classes.length} open={openSections.has("elements")} onToggle={() => toggleSection("elements")}>
        {data.classes.map((c, i) => (
          <ReviewItem key={i} id={`c-${i}`} label={`${c.name} (${c.attributes.length} attrs, ${c.methods.length} methods)`} excluded={excluded} onToggle={toggle} uncertain={c.uncertain} />
        ))}
      </ReviewSection>
      <ReviewSection title="Relationships" count={data.relationships.length} open={openSections.has("relationships")} onToggle={() => toggleSection("relationships")}>
        {data.relationships.map((r, i) => (
          <ReviewItem key={i} id={`r-${i}`} label={`${r.from} ${r.type} ${r.to}${r.cardinality ? ` [${r.cardinality}]` : ""}`} excluded={excluded} onToggle={toggle} uncertain={r.uncertain} autoFixed={r.auto_fixed} />
        ))}
      </ReviewSection>
    </>
  );

  const renderUseCase = (data: UseCaseDiagram) => (
    <>
      <ReviewSection title="Actors" count={data.actors.length} open={openSections.has("elements")} onToggle={() => toggleSection("elements")}>
        {data.actors.map((a, i) => (
          <ReviewItem key={i} id={`a-${i}`} label={a.name} excluded={excluded} onToggle={toggle} uncertain={a.uncertain} />
        ))}
      </ReviewSection>
      <ReviewSection title="Use Cases" count={data.usecases.length} open={openSections.has("usecases")} onToggle={() => toggleSection("usecases")}>
        {data.usecases.map((uc, i) => (
          <ReviewItem key={i} id={`uc-${i}`} label={`${uc.id}: ${uc.name}`} excluded={excluded} onToggle={toggle} uncertain={uc.uncertain} />
        ))}
      </ReviewSection>
      <ReviewSection title="Links" count={data.links.length} open={openSections.has("relationships")} onToggle={() => toggleSection("relationships")}>
        {data.links.map((l, i) => (
          <ReviewItem key={i} id={`l-${i}`} label={`${l.from} → ${l.to} (${l.type})`} excluded={excluded} onToggle={toggle} uncertain={l.uncertain} autoFixed={l.auto_fixed} />
        ))}
      </ReviewSection>
    </>
  );

  const renderGeneric = () => (
    <div className="p-3 rounded-md bg-muted/50 text-sm text-muted-foreground">
      <pre className="font-mono text-xs overflow-auto max-h-48">{JSON.stringify(result.data, null, 2)}</pre>
    </div>
  );

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <Check className="h-4 w-4 text-primary" />
          Review Extracted Elements
        </h3>
        <Badge variant="secondary" className="text-xs">{result.diagramType}</Badge>
      </div>

      {result.validationErrors.length > 0 && (
        <div className="p-3 rounded-md border border-destructive/40 bg-destructive/5 space-y-1">
          <p className="text-xs font-medium text-destructive">Validation Issues:</p>
          {result.validationErrors.map((e, i) => (
            <p key={i} className="text-xs text-destructive/80">• {e.message}</p>
          ))}
        </div>
      )}

      {result.autoFixes.length > 0 && (
        <div className="p-3 rounded-md border border-info/40 bg-info/5 space-y-1">
          <p className="text-xs font-medium text-info">Auto-fixes applied:</p>
          {result.autoFixes.map((f, i) => (
            <p key={i} className="text-xs text-info/80">• {f.description}: {f.oldValue} → {f.newValue}</p>
          ))}
        </div>
      )}

      <div className="space-y-2">
        {result.diagramType === "sequence" && renderSequence(result.data as SequenceDiagram)}
        {result.diagramType === "class" && renderClass(result.data as ClassDiagram)}
        {result.diagramType === "usecase" && renderUseCase(result.data as UseCaseDiagram)}
        {(result.diagramType === "activity" || result.diagramType === "state") && renderGeneric()}
      </div>

      <Button onClick={() => onConfirm(excluded)} disabled={isLoading} className="w-full">
        <Check className="h-4 w-4 mr-2" />
        Confirm & Generate PlantUML
      </Button>
    </div>
  );
}

function ReviewSection({ title, count, open, onToggle, children }: {
  title: string; count: number; open: boolean; onToggle: () => void; children: React.ReactNode;
}) {
  return (
    <Collapsible open={open} onOpenChange={onToggle}>
      <CollapsibleTrigger className="flex items-center gap-2 w-full text-left p-2 rounded-md hover:bg-muted/50 transition-colors">
        {open ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
        <span className="text-sm font-medium">{title}</span>
        <Badge variant="secondary" className="text-xs ml-auto">{count}</Badge>
      </CollapsibleTrigger>
      <CollapsibleContent className="pl-6 space-y-1 mt-1">
        {children}
      </CollapsibleContent>
    </Collapsible>
  );
}

function ReviewItem({ id, label, excluded, onToggle, uncertain, autoFixed }: {
  id: string; label: string; excluded: Set<string>; onToggle: (key: string) => void;
  uncertain?: boolean; autoFixed?: boolean;
}) {
  const isExcluded = excluded.has(id);
  return (
    <div className={`flex items-center gap-2 p-2 rounded text-sm transition-colors ${
      isExcluded ? "opacity-40" : uncertain ? "bg-warning/5" : autoFixed ? "bg-info/5" : ""
    }`}>
      <Checkbox checked={!isExcluded} onCheckedChange={() => onToggle(id)} className="h-4 w-4" />
      <span className={`flex-1 truncate ${isExcluded ? "line-through" : ""}`}>{label}</span>
      <ItemBadge uncertain={uncertain} autoFixed={autoFixed} />
    </div>
  );
}
