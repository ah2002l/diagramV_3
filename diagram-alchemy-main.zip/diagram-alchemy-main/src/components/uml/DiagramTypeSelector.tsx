import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { DiagramType, DiagramTypeDetection } from "@/types/uml";
import { AlertTriangle, CheckCircle, Target } from "lucide-react";

interface DiagramTypeSelectorProps {
  detection: DiagramTypeDetection | null;
  selectedType: DiagramType | null;
  onTypeChange: (type: DiagramType) => void;
  isDetecting: boolean;
}

const DIAGRAM_TYPES: { value: DiagramType; label: string }[] = [
  { value: "sequence", label: "Sequence Diagram" },
  { value: "class", label: "Class Diagram" },
  { value: "usecase", label: "Use Case Diagram" },
  { value: "activity", label: "Activity Diagram" },
  { value: "state", label: "State Diagram" },
];

export function DiagramTypeSelector({ detection, selectedType, onTypeChange, isDetecting }: DiagramTypeSelectorProps) {
  const lowConfidence = detection && detection.confidence < 0.7;

  return (
    <div className="space-y-3 animate-fade-in">
      <label className="flex items-center gap-2 text-sm font-medium text-foreground">
        <Target className="h-4 w-4 text-primary" />
        Diagram Type
      </label>

      {isDetecting && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground p-3 rounded-md bg-muted/50 border border-border">
          <div className="h-4 w-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          Detecting diagram type...
        </div>
      )}

      {detection && !isDetecting && (
        <div className={`p-3 rounded-md border text-sm space-y-1 ${
          lowConfidence ? "border-warning/40 bg-warning/5" : "border-success/40 bg-success/5"
        }`}>
          <div className="flex items-center gap-2">
            {lowConfidence ? (
              <AlertTriangle className="h-4 w-4 text-warning" />
            ) : (
              <CheckCircle className="h-4 w-4 text-success" />
            )}
            <span className="font-medium">
              Detected: {DIAGRAM_TYPES.find(d => d.value === detection.type)?.label}
            </span>
            <Badge variant={lowConfidence ? "destructive" : "secondary"} className="text-xs">
              {(detection.confidence * 100).toFixed(0)}%
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground">{detection.reasoning}</p>
          {lowConfidence && (
            <p className="text-xs text-warning font-medium">Low confidence — please verify or select manually</p>
          )}
        </div>
      )}

      <Select value={selectedType || ""} onValueChange={(v) => onTypeChange(v as DiagramType)}>
        <SelectTrigger className="bg-muted border-border">
          <SelectValue placeholder="Select or confirm type..." />
        </SelectTrigger>
        <SelectContent className="bg-popover border-border z-50">
          {DIAGRAM_TYPES.map((d) => (
            <SelectItem key={d.value} value={d.value}>
              {d.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
