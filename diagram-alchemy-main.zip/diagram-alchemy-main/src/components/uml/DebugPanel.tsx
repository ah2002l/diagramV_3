import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import type { DebugInfo } from "@/types/uml";
import { Bug, ChevronDown } from "lucide-react";
import { useState } from "react";

interface DebugPanelProps {
  info: DebugInfo | null;
}

export function DebugPanel({ info }: DebugPanelProps) {
  const [open, setOpen] = useState(false);

  if (!info) return null;

  return (
    <Collapsible open={open} onOpenChange={setOpen} className="animate-fade-in">
      <CollapsibleTrigger className="flex items-center gap-2 w-full text-left p-2 rounded-md bg-muted/30 hover:bg-muted/50 transition-colors border border-border">
        <Bug className="h-4 w-4 text-muted-foreground" />
        <span className="text-xs font-medium text-muted-foreground">Debug Panel</span>
        <ChevronDown className={`h-3 w-3 text-muted-foreground ml-auto transition-transform ${open ? "rotate-180" : ""}`} />
      </CollapsibleTrigger>
      <CollapsibleContent className="mt-2 p-3 rounded-md bg-muted/20 border border-border space-y-2 font-mono text-xs">
        <Row label="Model" value={info.model} />
        <Row label="Image Size" value={`${(info.imageSize / 1024).toFixed(1)} KB`} />
        <Row label="Detected Type" value={info.detectedType} />
        <Row label="Confidence" value={`${(info.confidence * 100).toFixed(0)}%`} />
        <Row label="Elements" value={String(info.elementCount)} />
        <Row label="Validation Errors" value={String(info.validationErrors)} badge={info.validationErrors > 0 ? "destructive" : undefined} />
        <Row label="Auto-fixes" value={String(info.autoFixes)} badge={info.autoFixes > 0 ? "info" : undefined} />
        {info.rawResponse && (
          <div className="pt-2 border-t border-border">
            <p className="text-muted-foreground mb-1">Raw LLM Response (truncated):</p>
            <pre className="text-xs text-foreground/70 overflow-auto max-h-32 whitespace-pre-wrap">
              {info.rawResponse.slice(0, 1000)}{info.rawResponse.length > 1000 ? "..." : ""}
            </pre>
          </div>
        )}
      </CollapsibleContent>
    </Collapsible>
  );
}

function Row({ label, value, badge }: { label: string; value: string; badge?: "destructive" | "info" }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-muted-foreground">{label}</span>
      {badge ? (
        <Badge variant={badge === "destructive" ? "destructive" : "secondary"} className={`text-xs ${badge === "info" ? "bg-info/20 text-info" : ""}`}>
          {value}
        </Badge>
      ) : (
        <span className="text-foreground">{value}</span>
      )}
    </div>
  );
}
