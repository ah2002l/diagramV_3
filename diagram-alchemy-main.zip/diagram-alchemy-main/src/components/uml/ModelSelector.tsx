import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MODEL_OPTIONS } from "@/types/uml";
import { Cpu } from "lucide-react";

interface ModelSelectorProps {
  value: string;
  onChange: (modelId: string) => void;
  disabled?: boolean;
}

export function ModelSelector({ value, onChange, disabled }: ModelSelectorProps) {
  return (
    <div className="space-y-2 animate-fade-in">
      <label className="flex items-center gap-2 text-sm font-medium text-foreground">
        <Cpu className="h-4 w-4 text-primary" />
        Extraction Model
      </label>
      <Select value={value} onValueChange={onChange} disabled={disabled}>
        <SelectTrigger className="bg-muted border-border">
          <SelectValue placeholder="Select model..." />
        </SelectTrigger>
        <SelectContent className="bg-popover border-border z-50">
          {MODEL_OPTIONS.map((m) => (
            <SelectItem key={m.id} value={m.id}>
              <div className="flex items-center gap-2">
                <span className="font-medium">{m.label}</span>
                <span className="text-xs text-muted-foreground">
                  {m.provider} · {m.speed}
                </span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
