import { useCallback, useState } from "react";
import { Upload, X, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ImageUploadProps {
  onImageSelect: (file: File, base64: string) => void;
  onClear: () => void;
  imagePreview: string | null;
  imageMimeType?: string | null;
  fileName: string | null;
  fileSize: number | null;
}

export function ImageUpload({ onImageSelect, onClear, imagePreview, imageMimeType, fileName, fileSize }: ImageUploadProps) {
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = useCallback((file: File) => {
    if (!file.type.match(/^image\/(png|jpe?g)$/)) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = (e.target?.result as string).split(",")[1];
      onImageSelect(file, base64);
    };
    reader.readAsDataURL(file);
  }, [onImageSelect]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  const handleClick = useCallback(() => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) handleFile(file);
    };
    input.click();
  }, [handleFile]);

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  if (imagePreview) {
    return (
      <div className="animate-fade-in space-y-3">
        <div className="relative rounded-lg border border-border overflow-hidden bg-muted/50">
          <img src={`data:${imageMimeType || "image/png"};base64,${imagePreview}`} alt="Uploaded UML" className="w-full max-h-64 object-contain" />
          <Button
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2 h-7 w-7"
            onClick={onClear}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <ImageIcon className="h-4 w-4" />
          <span className="truncate">{fileName}</span>
          {fileSize && <span className="text-xs">({formatSize(fileSize)})</span>}
        </div>
      </div>
    );
  }

  return (
    <div
      className={`animate-fade-in cursor-pointer rounded-lg border-2 border-dashed p-8 text-center transition-all duration-200 ${
        isDragging
          ? "border-primary bg-primary/5 glow-border"
          : "border-border hover:border-primary/50 hover:bg-muted/30"
      }`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onClick={handleClick}
    >
      <Upload className="mx-auto h-10 w-10 text-muted-foreground mb-3" />
      <p className="text-sm font-medium text-foreground">Drop your UML diagram here</p>
      <p className="text-xs text-muted-foreground mt-1">PNG or JPG supported</p>
    </div>
  );
}
