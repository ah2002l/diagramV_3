import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const DETECT_PROMPT = `You are a UML diagram type detector. Analyze this image and determine the UML diagram type.

RULES:
- ONLY identify what is VISUALLY present
- Do NOT guess or infer
- Return a JSON object with: type, confidence (0-1), reasoning

Valid types: sequence, class, usecase, activity, state

Indicators:
- Sequence: lifelines, arrows between participants, activation bars
- Class: compartmented boxes with attributes/methods, inheritance triangles
- Use Case: stick figures, ovals, system boundary rectangles
- Activity: diamond decision nodes, rounded action boxes, start/end nodes
- State: rounded rectangles with state names, transition arrows

Return ONLY valid JSON: {"type": "...", "confidence": 0.XX, "reasoning": "..."}`;

function getExtractionPrompt(diagramType: string): string {
  const schemas: Record<string, string> = {
    sequence: `Extract this sequence diagram to JSON:
{
  "participants": [{"name": "exact name", "alias": "optional", "kind": "actor|participant|boundary|control|entity|database"}],
  "messages": [{"order": 1, "from": "exact name", "to": "exact name", "label": "exact text", "type": "sync|async|return|create|destroy", "uncertain": false}]
}`,
    class: `Extract this class diagram to JSON:
{
  "classes": [{"name": "exact name", "attributes": [{"name": "name", "type": "type", "visibility": "+|-|#|~"}], "methods": [{"name": "name", "returnType": "type", "params": "params", "visibility": "+|-|#|~"}]}],
  "relationships": [{"from": "class name", "to": "class name", "type": "inheritance|implementation|association|aggregation|composition|dependency", "cardinality": "optional", "label": "optional"}]
}`,
    usecase: `Extract this use case diagram to JSON:
{
  "actors": [{"name": "exact name"}],
  "usecases": [{"id": "UC1", "name": "exact name"}],
  "links": [{"from": "actor or UC id", "to": "actor or UC id", "type": "association|include|extend|generalization"}]
}`,
    activity: `Extract this activity diagram to JSON:
{
  "nodes": [{"id": "N1", "name": "exact label", "type": "action|decision|fork|join|start|end"}],
  "edges": [{"from": "node id", "to": "node id", "label": "optional guard text"}]
}`,
    state: `Extract this state diagram to JSON:
{
  "states": [{"id": "S1", "name": "exact name", "type": "state|start|end|composite"}],
  "transitions": [{"from": "state id", "to": "state id", "trigger": "optional", "guard": "optional"}]
}`,
  };

  const schema = schemas[diagramType] || schemas.sequence;

  return `${schema}

CRITICAL RULES - NO HALLUCINATION:
- ONLY extract elements that are VISUALLY PRESENT in the image
- Do NOT infer, guess, or add elements not shown
- Preserve EXACT names, labels, and casing from the diagram
- If any element is unclear or partially visible, set "uncertain": true
- NEVER invent relationships or elements not explicitly drawn
- If text is unreadable, use "uncertain": true and your best guess for the text

Return ONLY valid JSON matching the schema above.`;
}

function normalizeImageMimeType(imageMimeType?: string): string {
  if (!imageMimeType) return "image/png";
  const normalized = imageMimeType.toLowerCase();
  if (normalized === "image/jpg") return "image/jpeg";
  if (normalized === "image/png" || normalized === "image/jpeg") return normalized;
  return "image/png";
}

function buildImageDataUrl(imageBase64: string, imageMimeType?: string): string {
  if (imageBase64.startsWith("data:image/")) return imageBase64;
  return `data:${normalizeImageMimeType(imageMimeType)};base64,${imageBase64}`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, imageBase64, imageMimeType, diagramType, model } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");
    if (!imageBase64 || typeof imageBase64 !== "string") {
      return new Response(JSON.stringify({ error: "Missing or invalid imageBase64" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const backendModel = model || "google/gemini-3-flash-preview";
    const imageDataUrl = buildImageDataUrl(imageBase64, imageMimeType);

    let systemPrompt: string;
    let userContent: any[];

    if (action === "detect") {
      systemPrompt = DETECT_PROMPT;
      userContent = [
        { type: "image_url", image_url: { url: imageDataUrl } },
        { type: "text", text: "What type of UML diagram is this? Return JSON only." },
      ];
    } else if (action === "extract") {
      systemPrompt = getExtractionPrompt(diagramType);
      userContent = [
        { type: "image_url", image_url: { url: imageDataUrl } },
        { type: "text", text: "Extract all elements from this UML diagram. Return JSON only." },
      ];
    } else {
      return new Response(JSON.stringify({ error: "Invalid action" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: backendModel,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent },
        ],
        temperature: 0.1,
        max_tokens: 4096,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits in Settings." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      let details = "";
      if (errText) {
        try {
          const parsed = JSON.parse(errText);
          details = parsed?.error?.message || parsed?.message || errText;
        } catch {
          details = errText;
        }
      }
      const detailSuffix = details ? ` - ${String(details).slice(0, 300)}` : "";
      return new Response(JSON.stringify({ error: `AI gateway error: ${response.status}${detailSuffix}` }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiResult = await response.json();
    const rawContent = aiResult.choices?.[0]?.message?.content || "";

    // Parse JSON from response (handle markdown code blocks)
    let parsed;
    try {
      const jsonMatch = rawContent.match(/```(?:json)?\s*([\s\S]*?)```/) || [null, rawContent];
      const cleanJson = (jsonMatch[1] || rawContent).trim();
      parsed = JSON.parse(cleanJson);
    } catch {
      return new Response(JSON.stringify({ error: "Failed to parse AI response", raw: rawContent }), {
        status: 422,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ result: parsed, raw: rawContent, model: backendModel }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("extract-uml error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
